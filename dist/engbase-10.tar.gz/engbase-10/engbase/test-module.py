

class TestClass():

    def __init__(self) -> None:

        pass

    def test_function():
        """
        This is a docstring.

        """

        print('Hello World')
